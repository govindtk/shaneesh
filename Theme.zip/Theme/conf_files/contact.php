
<?php

$name=$_POST['val'];
echo "Message sent successfully...".$name;
//$email=$_POST['email'];
//$subject=$_POST['subject'];
//$comments=$_POST['comments'];
// $retval = mail ('mshaneesh@gmail.com',$subject,$comments,$name);
//         
//         if( $retval == true ) {
//            echo "Message sent successfully...";
//         }else {
//            echo "Message could not be sent...";
//         }
?>